<?php
namespace tasks\demo\lib;
use core\lib\Utils;
class Demolib{
    
    public function run(){
        Utils::log('Demolib run ok'); 
    }
}
