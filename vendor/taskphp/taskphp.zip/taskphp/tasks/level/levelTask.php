<?php
namespace tasks\level;
use core\lib\Task;
use core\lib\Utils;
use core\lib\http\Client;
/**
 * 测试任务 
 */
class levelTask extends Task{
    /**
     * 任务入口
     * (non-PHPdoc)
     * @see \core\lib\Task::run()
     */
	public function run(){

	    Utils::dbConfig(Utils::config('DB','level'));

        $maxLives = Utils::model("develop")->find();
        // $average = $maxLives['lives_tree']/3;
        $average = 40;

	    //40<live<80
	    $map['lifes'] = array('between',array($average*1,$average*2));
        $data['level'] = 2;
	    Utils::model("trees")->where($map)->save($data);

        //80<live<120
        $map1['lifes'] = array('between',array($average*2,$average*3));
        $data1['level'] = 3;
        Utils::model("trees")->where($map1)->save($data1);

        //live ==120
        $map2['lifes'] = 120;
        $map2['status'] = 0;
        $data2['status'] = 1;
        Utils::model("trees")->where($map2)->save($data2);

       
        
        //生成果实
        $sql2 = 'insert into game_furit(trees_id,type) SELECT a.id,ceiling(RAND()*2) as type FROM game_trees a WHERE ( SELECT count(id) as count FROM game_furit WHERE game_furit.trees_id = a.id) <2 and lifes = 120 and status=1 and prop_use=1';
        Utils::model("furit")->execute($sql2);

        //prop使用情况 
        
        //使用
//         $sql = 'update game_trees a inner join (select trees_id,count(*) as typeCount from game_my_prop where status = 1  group by prop_type)b inner join (select  trees_id,count(*) as count from game_furit where status=1) c
// set a.status = 3 where a.id = b.trees_id and a.lifes = 120  and b.typeCount=3 and a.status <3 and c.count=2';
        $sql = 'update game_trees a  inner join (select  trees_id,count(*) as count from game_furit where status=1) c
set a.status = 3 where a.lifes = 120  and a.prop_use=1 and a.status <3 and c.count=2';
        Utils::model("trees")->execute($sql);
        //未使用
//         $sql1 = 'update game_trees a inner join (select trees_id,count(*) as typeCount from game_my_prop where status = 1  group by prop_type)b inner join (select  trees_id,count(*) as count from game_furit where status=0) c
// set a.status = 2 where a.id = b.trees_id and a.lifes = 120  and b.typeCount=3 and a.status <3 and c.count>0';
        $sql1 = 'update game_trees a inner join (select  trees_id,count(*) as count from game_furit where status=0) c
set a.status = 2 where  a.lifes = 120  and a.prop_use=1 and a.status <3 and c.count>0';
        Utils::model("trees")->execute($sql1);
       
        

		flush();
	}
}
