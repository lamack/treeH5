<?php
namespace tasks\growup;
use core\lib\Task;
use core\lib\Utils;
use core\lib\http\Client;
/**
 * 测试任务 
 */
class growupTask extends Task{
    /**
     * 任务入口
     * (non-PHPdoc)
     * @see \core\lib\Task::run()
     */
	public function run(){

	    Utils::dbConfig(Utils::config('DB','growup'));

	    //live<120 每小时1点
	    $map['lifes'] = array('lt',120);

	    Utils::model("trees")->where($map)->setInc('lifes',1);

		flush();
	}
}
