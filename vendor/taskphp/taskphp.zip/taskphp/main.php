<?php
/**
 * taskPHP
 * @author     码农<8044023@qq.com>,cqcqphper 小草<cqcqphper@163.com>
 * @copyright  taskPHP
 * @license    https://git.oschina.net/cqcqphper/taskPHP
 */
 /**
  * 统一入口
  * 
  */
include_once __DIR__."/core/guide.php";
core\lib\Command::run();